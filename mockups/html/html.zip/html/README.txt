,`*DOMAIN QUESTIONNAIRE*`,

1. List 10 available domains (use http://iwantmyname.com) you think would be appropriate for your site:

thegoldenrule.com
neverrevealyouridentity.com
nicetomeetyou.com
himynameis.com
youcancallmesuperhero.com
  
2. What type or genre of domain is this? (Ex. Game, Toy, Greeting Card Generator, Creative Tool, Political Pamphlet, Archive)

Interactive Story, Digitial Poetry, Story
  
3. Write a small story (one paragraph or so) that details a user's experience of discovering your domain, visiting it within a particular context (like mobile, desktop, while hungry, at a funeral, etc.), experiencing what it has to offer, and subsequently leaving.

Ideally, a user would hear about this project by me. They would get either a QR code, or a link to the website.
they slowly navigate the page and are somewhat confused as to how to interact with it. 
Once they experiment with it for a while they finally watch as the story unfolds. 
They get to the end and their entire life purpose has been changed. 
They leave the page with a newfound appreciation for life.
They smile.
They recommend it to others. :)
  
4. Would somebody return to your domain after visiting it for the first time - in how long do you think - and why?

Probably not frequently. But the same time you need to reread poetry, need a pickup or need inspiration you would come back. I find myself revisiting spoken word poems all the time.
  
5. List some 'stuff' that your site 'does'. (Be detailed)

The website is a navigational structure for a poem. It interacts with text and a story in an interesting way that isn't just text on a page.
For instance you hav to hover over certain parts of the page to get certain passages to appear. Maybe you have to click? Drag elements around to trigger certain passages? Maybe there is user input? Basically anything interesting to get the user to have to interact with the words with another method that isn't just reading.
